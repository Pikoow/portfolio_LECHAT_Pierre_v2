DROP SCHEMA IF EXISTS colleges CASCADE;

CREATE SCHEMA colleges;

SET SCHEMA 'colleges';

CREATE TABLE _region (
  id_region SERIAL PRIMARY KEY,
  code_region VARCHAR(255) UNIQUE NOT NULL,
  libelle_region VARCHAR(255) NOT NULL
);

CREATE TABLE _academie (
  id_academie SERIAL PRIMARY KEY,
  code_academie VARCHAR(255) UNIQUE NOT NULL,
  lib_academie VARCHAR(255) NOT NULL
);

CREATE TABLE _departement (
  id_departement SERIAL PRIMARY KEY,
  code_departement VARCHAR(255) UNIQUE NOT NULL,
  nom_departement VARCHAR(255) NOT NULL,
  id_region INTEGER NOT NULL REFERENCES _region(id_region)
);

CREATE TABLE _commune (
  id_commune SERIAL PRIMARY KEY,
  code_insee_de_la_commune VARCHAR(255) UNIQUE NOT NULL,
  nom_de_la_commune VARCHAR(255) NOT NULL,
  code_postal VARCHAR(255),
  id_departement INTEGER NOT NULL REFERENCES _departement(id_departement)
);

CREATE TABLE _etablissement (
  uai VARCHAR(255) PRIMARY KEY,
  nom_etablissement VARCHAR(255) NOT NULL,
  type_etablissement VARCHAR(255) NOT NULL,
  adresse VARCHAR(255) NOT NULL,
  code_postal VARCHAR(255) NOT NULL,
  latitude DECIMAL(10,6),
  longitude DECIMAL(10,6),
  id_commune INTEGER NOT NULL REFERENCES _commune(id_commune),
  id_academie INTEGER NOT NULL REFERENCES _academie(id_academie),
  code_quartier_prioritaire VARCHAR(255)
);

CREATE TABLE caracteristiques_tout_etablissement (
  uai VARCHAR(255) PRIMARY KEY REFERENCES _etablissement(uai),
  effectifs INTEGER,
  ips FLOAT,
  ecart_type_de_l_ips FLOAT,
  ep VARCHAR(255)
);

CREATE TABLE caracteristiques_college (
  uai VARCHAR(255) PRIMARY KEY REFERENCES _etablissement(uai),
  nbre_eleves_hors_segpa_hors_ulis INTEGER,
  nbre_eleves_segpa INTEGER,
  nbre_eleves_ulis INTEGER
);

CREATE TABLE caracteristiques_selon_classe (
  id_classe SERIAL PRIMARY KEY,
  uai VARCHAR(255) NOT NULL REFERENCES _etablissement(uai),
  code_nature VARCHAR(255) NOT NULL,
  nbre_eleves_hors_segpa_hors_ulis_selon_niveau INTEGER,
  nbre_eleves_segpa_selon_niveau INTEGER,
  nbre_eleves_ulis_selon_niveau INTEGER,
  effectif_filles INTEGER,
  effectif_garcons INTEGER
);

CREATE TABLE quartier_prioritaire (
  code_quartier_prioritaire VARCHAR(255) PRIMARY KEY,
  nom_quartier_prioritaire VARCHAR(255) NOT NULL
);

CREATE TABLE _type (
  id_type SERIAL PRIMARY KEY,
  code_nature VARCHAR(255) UNIQUE NOT NULL,
  libelle_nature VARCHAR(255) NOT NULL
);

CREATE TABLE _classe (
  id_classe VARCHAR(25) PRIMARY KEY
);

ALTER TABLE _etablissement
ADD CONSTRAINT fk_etablissement_code_quartier_prioritaire
FOREIGN KEY (code_quartier_prioritaire) REFERENCES quartier_prioritaire(code_quartier_prioritaire);

ALTER TABLE caracteristiques_selon_classe
ADD CONSTRAINT fk_caracteristiques_selon_classe_type
FOREIGN KEY (code_nature) REFERENCES _type(code_nature);
