import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt

vueDF = pd.read_csv("vue.csv")

vueDF = vueDF.dropna()

vueAR = vueDF.to_numpy()

vueAR = vueAR[:, [1, 2, 3, 4, 5]]

print(vueAR)

def Centreduire(T):
    T = np.array(T, dtype = np.float64)
    moyennes = np.mean(T, axis = 0)
    ecarts_types = np.std(T, axis = 0)
    Res = (T - moyennes) / ecarts_types

    return Res

print(Centreduire(vueAR))

def DiagBatons(Colonne):
    m = np.min(Colonne)
    M = np.max(Colonne)
    inter = np.linspace(m, M, 21)
    
    plt.figure()
    plt.hist(Colonne, bins=inter)
    plt.title('Diagramme en bâtons')
    plt.xlabel('Valeurs')
    plt.ylabel('Fréquence')
    plt.show()

DiagBatons(vueAR[:,[0]])

X = vueAR[:, :-1]
y = vueAR[:, -1]

regression_model = LinearRegression()

regression_model.fit(X, y)

r_squared = regression_model.score(X, y)

multiple_correlation_coefficient = np.sqrt(r_squared)

print("Coefficient de détermination R^2 : " + r_squared)
print("Coefficient de corrélation multiple : " + multiple_correlation_coefficient)